#include "Node.h"
Node::Node(int d)
{
	data = d;
	parent = nullptr;
	right = nullptr;
	left = nullptr;
}